#  Copyright 2021 ETH Zurich, NVIDIA CORPORATION
#  SPDX-License-Identifier: BSD-3-Clause

"""Main module for the rsl_rl package."""

__version__ = "2.0.1"
__license__ = "BSD-3"
